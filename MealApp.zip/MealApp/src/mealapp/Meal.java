/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mealapp;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Administrator
 */
@Entity
@Table(name = "MEAL")
@NamedQueries({
    @NamedQuery(name = "Meal.findAll", query = "SELECT m FROM Meal m"),
    @NamedQuery(name = "Meal.findByIdmeal", query = "SELECT m FROM Meal m WHERE m.idmeal = :idmeal"),
    @NamedQuery(name = "Meal.findByStrmeal", query = "SELECT m FROM Meal m WHERE m.strmeal = :strmeal"),
    @NamedQuery(name = "Meal.findByStrcategory", query = "SELECT m FROM Meal m WHERE m.strcategory = :strcategory"),
    @NamedQuery(name = "Meal.findByStrarea", query = "SELECT m FROM Meal m WHERE m.strarea = :strarea"),
    @NamedQuery(name = "Meal.findByStrinstructions", query = "SELECT m FROM Meal m WHERE m.strinstructions = :strinstructions"),
    @NamedQuery(name = "Meal.findByStatus", query = "SELECT m FROM Meal m WHERE m.status = :status")})
public class Meal implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "IDMEAL")
    private Integer idmeal;
    @Column(name = "STRMEAL")
    private String strmeal;
    @Column(name = "STRCATEGORY")
    private String strcategory;
    @Column(name = "STRAREA")
    private String strarea;
    @Column(name = "STRINSTRUCTIONS")
    private String strinstructions;
    @Column(name = "STATUS")
    private Integer status;

    public Meal() {
    }

    public Meal(Integer idmeal) {
        this.idmeal = idmeal;
    }

    public Integer getIdmeal() {
        return idmeal;
    }

    public void setIdmeal(Integer idmeal) {
        this.idmeal = idmeal;
    }

    public String getStrmeal() {
        return strmeal;
    }

    public void setStrmeal(String strmeal) {
        this.strmeal = strmeal;
    }

    public String getStrcategory() {
        return strcategory;
    }

    public void setStrcategory(String strcategory) {
        this.strcategory = strcategory;
    }

    public String getStrarea() {
        return strarea;
    }

    public void setStrarea(String strarea) {
        this.strarea = strarea;
    }

    public String getStrinstructions() {
        return strinstructions;
    }

    public void setStrinstructions(String strinstructions) {
        this.strinstructions = strinstructions;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idmeal != null ? idmeal.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Meal)) {
            return false;
        }
        Meal other = (Meal) object;
        if ((this.idmeal == null && other.idmeal != null) || (this.idmeal != null && !this.idmeal.equals(other.idmeal))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "mealapp.Meal[ idmeal=" + idmeal + " ]";
    }
    
}
