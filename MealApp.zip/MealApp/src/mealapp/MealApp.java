/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mealapp;

/**
 *
 * @author Administrator
 */
public class MealApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        TheMeal_R1 r1 = new TheMeal_R1();
        r1.setTitle("TheMealApp");
        r1.setLocationRelativeTo(null);
        r1.setVisible(true);
    }
    
}
